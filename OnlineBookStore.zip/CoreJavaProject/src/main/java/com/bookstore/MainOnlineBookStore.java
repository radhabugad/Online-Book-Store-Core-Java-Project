package com.bookstore;
import java.sql.SQLException;
import java.util.Scanner;


class BuyerMenu {
	
    private int userID;

    public BuyerMenu(int userID) {
        this.userID = userID;
    }

    public void showBuyerMenu() throws SQLException {
        int choice;
        Scanner sc = new Scanner(System.in);

        do {
            System.out.println("=== Buyer Menu ===");
            System.out.println("1. View Books");
            System.out.println("2. Order Books");
            System.out.println("3. View Delivery Status");
            System.out.println("4. Exit");

            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("Viewing books as a buyer...");
                    DataBaseOperations.viewBooks(userID);
                    
                    break;
             case 2:
                    System.out.println("Ordering books as a buyer...");
                    DataBaseOperations.orderBooks(userID);
                    break;
             case 3:
                 System.out.println("Viewing delivery status as a buyer...");
//                 System.out.println("Enter your order ID to check status: ");
//                 int orderID = sc.nextInt();
                 DataBaseOperations.viewOrderID(userID);
                 //DataBaseOperations.viewDeliveryStatus(orderID);
                 break;
             case 4:
                    System.out.println("Exiting Buyer Menu...");
                    break;
              default:
                    System.out.println("Invalid choice. Please try again.");
            }
           }
         while (choice != 3);
    }

}

class SellerMenu {
    private int userID;

    public SellerMenu(int userID) {
        this.userID = userID;
    }

    public void showSellerMenu() throws Exception {
        int choice;
        Scanner sc = new Scanner(System.in);

        do {
            System.out.println("=== Seller Menu ===");
            System.out.println("1. View Books");
            System.out.println("2. Add New Book");
            System.out.println("3. Update Book");
            System.out.println("4. Delete Book");
            System.out.println("5. View Buyers");
            System.out.println("6. View All Orders");
            System.out.println("7. Update Delivery Status");
            System.out.println("8. View Delivery Status");
            System.out.println("9. Exit");

            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("Viewing books as a seller...");
                    DataBaseOperations.viewBooks(userID);
                    break;
                case 2:
                    System.out.println("Adding a new book as a seller...");
                    System.out.print("Enter book title: ");
                    sc.nextLine();
                    String title = sc.nextLine();

                    System.out.print("Enter book author: ");
                    String author = sc.nextLine();

                    System.out.print("Enter book price: ");
                    float price = sc.nextFloat();

                    System.out.print("Enter book quantity: ");
                    int quantity = sc.nextInt();
                    
                    DataBaseOperations.addNewBook(title,author,price,quantity);
                    break;
                case 3:
                    System.out.println("Updating a book details as a seller...");
                    DataBaseOperations.updateBook();
                    break;
                case 4:
                    System.out.println("Deleting a book as a seller...");
                    DataBaseOperations.deleteBook();
                    break;
                case 5:
                	System.out.println("Viewing Buyers...");
                	DataBaseOperations.viewBuyers();
                	break;
                case 6:
                    System.out.println("Viewing All Orders...");
                    DataBaseOperations.viewOrderDetails();
                    break;
                case 7:
                    System.out.println("Updating Delivery Status...");
                    System.out.println("Enter order id to update status");
                    int oid=sc.nextInt();
                   DataBaseOperations.updateDeliveryStatus(oid);
                    break;
                    
                case 8:
                	
                	    System.out.println("Viewing Delivery Status...");
                	    System.out.print("Enter the Order ID to view delivery status: ");
                	    int orderIDToView = sc.nextInt();
                	    DataBaseOperations.viewDeliveryStatus(orderIDToView);
                    
                    break;
                	
                case 9:
                    System.out.println("Exiting Seller Menu...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 5);
    }
}



public class MainOnlineBookStore {

	public static void main(String[] args) throws Exception {
		int choice;
		for(;;) {
			Scanner sc = new Scanner(System.in);
			System.out.println("=== Online Book Store ===");
			System.out.println("Enter your choice: ");
			System.out.println("1. User Registration");
			System.out.println("2. User Login");
			
			choice = sc.nextInt();
			switch(choice) {
			case 1:
				System.out.println("=== User Registration ===");
				sc.nextLine();
				// Collect user input
		        System.out.print("Enter username: ");
		        String inputUsername = sc.nextLine();

		        System.out.print("Enter email: ");
		        String inputEmail = sc.nextLine();

		        System.out.print("Enter password: ");
		        String inputPassword = sc.nextLine();
		        
		        System.out.print("Choose role (BUYER or SELLER): ");
		        String role = sc.nextLine().toUpperCase();
		        
				DataBaseOperations.performUserRegistration(inputUsername,inputEmail,inputPassword,role);
				break;
			case 2:
				System.out.println("=== User Login ===");
				sc.nextLine();

		        // Collect user input
		        System.out.print("Enter username: ");
		        String loginUsername = sc.nextLine();

		        System.out.print("Enter password: ");
		        String loginPassword = sc.nextLine();
				DataBaseOperations.userLogin(loginUsername,loginPassword);
			}
		}
		

	}


}
