package com.bookstore;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class DataBaseOperations {
	  private static Connection conn;	  
	  private static PreparedStatement pst;
	  private static String sql;
	  private static ResultSet rs;
	  private static Scanner sc = new Scanner(System.in);
	  
	  public static void performUserRegistration(String inputUsername,String inputEmail,String inputPassword,String role) throws Exception {
		  conn = DataBaseConnection.getConnection();
		  
		  // SQL query for inserting a new user
		  sql = "insert into Users(Username, Email,Password,Role) values(?,?,?,?)";
		  pst = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
		  
		  // Set values for the placeholders in the query
		  pst.setString(1, inputUsername);
		  pst.setString(2, inputEmail);
		  pst.setString(3, inputPassword);
		  pst.setString(4, role);
		  
		  // Execute the query to insert the new user
	        int affectedRows = pst.executeUpdate();

	        if (affectedRows > 0) {
	            System.out.println("User registration successful!");

	            // Get the generated user ID
	            rs = pst.getGeneratedKeys();
	            if (rs.next()) {
	                int userID = rs.getInt(1);

	                // Insert into the appropriate role-specific table
	                if ("BUYER".equals(role)) {
	                    insertBuyer(userID);
	                    BuyerMenu buyerMenu = new BuyerMenu(userID);
	                    buyerMenu.showBuyerMenu();
	                } else if ("SELLER".equals(role)) {
	                    insertSeller(userID);
	                    SellerMenu sellerMenu = new SellerMenu(userID);
	                    sellerMenu.showSellerMenu();
	                }
	            }
	        } else {
	            System.out.println("User registration failed. Please try again.");
	        }
	    }

	    private static void insertBuyer(int userID) throws SQLException {
	        String sql = "INSERT INTO Buyers(UserID) VALUES (?)";
	        pst = conn.prepareStatement(sql);
	        pst.setInt(1, userID);
	        pst.executeUpdate();
	    }

	    private static void insertSeller(int userID) throws SQLException {
	        String sql = "INSERT INTO Sellers(UserID) VALUES (?)";
	        pst = conn.prepareStatement(sql);
	        pst.setInt(1, userID);
	        pst.executeUpdate();
	    }
	
	  public static void userLogin(String loginUsername,String loginPassword) throws Exception {
	        conn = DataBaseConnection.getConnection();

	        // SQL query for user authentication
	        String sql = "SELECT * FROM Users WHERE Username = ? AND Password = ?";
	        pst = conn.prepareStatement(sql);
	        pst.setString(1, loginUsername);
	        pst.setString(2, loginPassword);
	        rs = pst.executeQuery();

	        if (rs.next()) {
	            System.out.println("Login successful!");

	            // Add logic for authenticated user
	            String role = rs.getString("Role");
	            int userID = rs.getInt("UserID");

	            if ("BUYER".equals(role)) {
	                BuyerMenu buyerMenu = new BuyerMenu(userID);
	                buyerMenu.showBuyerMenu();
	            } else if ("SELLER".equals(role)) {
	                SellerMenu sellerMenu = new SellerMenu(userID);
	                sellerMenu.showSellerMenu();
	            } else {
	                System.out.println("Invalid user role.");
	            }
	        }else {
	            System.out.println("Invalid username or password. Please try again.");
	        }
	        }
	  
	  public static void viewBooks(int userID) throws SQLException {
	        conn = DataBaseConnection.getConnection();

	        // SQL query to retrieve books for the buyer
	        String sql = "SELECT * FROM Books";
	        pst = conn.prepareStatement(sql);
	        rs = pst.executeQuery();

	        System.out.format("%-10s %-30s %-20s %-10s %-10s%n",
	                "Book ID", "Title", "Author", "Price", "Quantity");
	        System.out.println("------------------------------------------------------------");

	        while (rs.next()) {
	            // Display book information in tabular format
	            System.out.format("%-10d %-30s %-20s $%-9.2f %-10d%n",
	                    rs.getInt("BookID"),
	                    rs.getString("Title"),
	                    rs.getString("Author"),
	                    rs.getFloat("Price"),
	                    rs.getInt("Quantity"));
	        }
	    }
	  
	  
	  
	  public static void orderBooks(int userID) throws SQLException {
		  conn = DataBaseConnection.getConnection();
		  
		  //Display available books
		  viewBooks(userID);
		  
		  System.out.print("Enter the Book ID to order: ");
		  int bookID = sc.nextInt();
		  
		  //SQL query to insert a new order
		  String sql = "INSERT INTO ORDERS(UserID,BookID) VALUES(?, ?)";
		  pst=conn.prepareStatement(sql);
		  pst.setInt(1, userID);
		  pst.setInt(2, bookID);
		  
		  int affectedRows = pst.executeUpdate();

	        if (affectedRows > 0) {
	            System.out.println("Order placed successfully!");
	        } else {
	            System.out.println("Failed to place the order. Please try again.");
	        }	  
		  
	  }
	  
	  public static void addNewBook(String title,String author, float price,int quantity) throws SQLException {
		  conn = DataBaseConnection.getConnection();
		// SQL query to insert a new book
	        String sql = "INSERT INTO Books(Title, Author, Price, Quantity) VALUES (?, ?, ?, ?)";
	        
	        pst = conn.prepareStatement(sql);
            pst.setString(1, title);
            pst.setString(2, author);
            pst.setFloat(3, price);
            pst.setInt(4, quantity);

            int affectedRows = pst.executeUpdate();

            if (affectedRows > 0) {
                System.out.println("New book added successfully!");
            } else {
                System.out.println("Failed to add the new book. Please try again.");
            }
	        
		  
	  }
	  
	  
	  public static void updateBook() throws Exception {
		  
		  conn = DataBaseConnection.getConnection();

	        System.out.print("Enter the Book ID to update: ");
	        int bookID = sc.nextInt();

	        System.out.println("Select the field to update:");
	        System.out.println("1. Title");
	        System.out.println("2. Author");
	        System.out.println("3. Price");
	        System.out.println("4. Quantity");

	        int fieldChoice = sc.nextInt();
	        sc.nextLine(); // Consume the newline character

	        switch (fieldChoice) {
	            case 1:
	                System.out.print("Enter the new title for the book: ");
	                String newTitle = sc.nextLine();
	                // SQL query to update the title for the book
	                String titleUpdateQuery = "UPDATE Books SET Title = ? WHERE BookID = ?";
	                pst = conn.prepareStatement(titleUpdateQuery);
	                pst.setString(1, newTitle);
	                pst.setInt(2, bookID);
	                break;
	            case 2:
	                System.out.print("Enter the new author for the book: ");
	                String newAuthor = sc.nextLine();
	                // SQL query to update the author for the book
	                String authorUpdateQuery = "UPDATE Books SET Author = ? WHERE BookID = ?";
	                pst = conn.prepareStatement(authorUpdateQuery);
	                pst.setString(1, newAuthor);
	                pst.setInt(2, bookID);
	                break;
	            case 3:
	                System.out.print("Enter the new price for the book: ");
	                float newPrice = sc.nextFloat();
	                // SQL query to update the price for the book
	                String priceUpdateQuery = "UPDATE Books SET Price = ? WHERE BookID = ?";
	                pst = conn.prepareStatement(priceUpdateQuery);
	                pst.setFloat(1, newPrice);
	                pst.setInt(2, bookID);
	                break;
	            case 4:
	                System.out.print("Enter the new quantity for the book: ");
	                int newQuantity = sc.nextInt();
	                // SQL query to update the quantity for the book
	                String quantityUpdateQuery = "UPDATE Books SET Quantity = ? WHERE BookID = ?";
	                pst = conn.prepareStatement(quantityUpdateQuery);
	                pst.setInt(1, newQuantity);
	                pst.setInt(2, bookID);
	                break;
	            default:
	                System.out.println("Invalid choice. Please try again.");
	                return;
	        }

	        int affectedRows = pst.executeUpdate();

	        if (affectedRows > 0) {
	            System.out.println("Book field updated successfully!");
	        } else {
	            System.out.println("Failed to update book field. Please try again.");
	        }
	    }

	  
	  public static void deleteBook() throws SQLException {
	        conn = DataBaseConnection.getConnection();

	        System.out.print("Enter the Book ID to delete: ");
	        int bookID = sc.nextInt();

	        // SQL query to delete the book
	        String deleteQuery = "DELETE FROM Books WHERE BookID = ?";
	        pst = conn.prepareStatement(deleteQuery);
	        pst.setInt(1, bookID);

	        int affectedRows = pst.executeUpdate();

	        if (affectedRows > 0) {
	            System.out.println("Book deleted successfully!");
	        } else {
	            System.out.println("Failed to delete book. Please make sure the Book ID is correct.");
	        }
	    }
	  
	  
	  public static void viewBuyers() throws SQLException {
	        conn = DataBaseConnection.getConnection();

	        // SQL query to retrieve buyers' information
	        String query = "SELECT Users.Username, Buyers.BuyerID FROM Users INNER JOIN Buyers ON Users.UserID = Buyers.UserID";
	        pst = conn.prepareStatement(query);
	        rs = pst.executeQuery();

	        System.out.println("=== Buyers List ===");

	     // Display header
	        System.out.printf("%-15s%-15s%n", "Buyer ID", "Username");
	        System.out.println("----------------------------");

	        while (rs.next()) {
	            // Display buyer information in tabular format
	            System.out.printf("%-15d%-15s%n", rs.getInt("BuyerID"), rs.getString("Username"));
	        }
	    }
	  
	  
	  public static void viewOrderDetails() throws SQLException {
	        conn = DataBaseConnection.getConnection();

	        // SQL query to retrieve order details
	        String query = "SELECT Orders.OrderID, Users.Username, Books.Title, Orders.OrderDate " +
	                "FROM Orders " +
	                "INNER JOIN Users ON Orders.UserID = Users.UserID " +
	                "INNER JOIN Books ON Orders.BookID = Books.BookID";
	        pst = conn.prepareStatement(query);
	        rs = pst.executeQuery();

	        System.out.println("=== Order Details ===");

	        // Display header
	        System.out.printf("%-10s%-20s%-30s%-20s%n", "Order ID", "Buyer Username", "Book Title", "Order Date");
	        System.out.println("---------------------------------------------------------------");

	        while (rs.next()) {
	            // Display order details in tabular format
	            System.out.printf("%-10d%-20s%-30s%-20s%n", rs.getInt("OrderID"), rs.getString("Username"),
	                    rs.getString("Title"), rs.getString("OrderDate"));
	        }
	    }
	  
	  
	  
	  
	  

	        
	
	        
	  

	        
	  public static void updateDeliveryStatus(int orderID) {
	        try {
	            conn = DataBaseConnection.getConnection();

	            // Display current delivery status
	            String currentStatus = getCurrentDeliveryStatus(orderID);
	            System.out.println("Current Delivery Status: " + currentStatus);

	            // Prompt for new delivery status
	            System.out.print("Enter new Delivery Status (delivered, pending, processing): ");
	            String newStatus = sc.nextLine().toLowerCase();  // Convert the status to lowercase

	            // Check if the new status is valid (delivered, pending, or processing)
	            if (!isValidStatus(newStatus)) {
	                System.out.println("Invalid delivery status. Please enter 'delivered', 'pending', or 'processing'.");
	                return;
	            }

	            // SQL query to update delivery status for a specific order
	            String query = "UPDATE Orders SET DeliveryStatus = ? WHERE OrderID = ?";
	            pst = conn.prepareStatement(query);
	            pst.setString(1, newStatus);
	            pst.setInt(2, orderID);

	            int rowsUpdated = pst.executeUpdate();

	            if (rowsUpdated > 0) {
	                System.out.println("Delivery Status updated for Order ID " + orderID);
	            } else {
	                System.out.println("Failed to update Delivery Status for Order ID " + orderID);
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    private static String getCurrentDeliveryStatus(int orderID) throws SQLException {
	        // SQL query to retrieve current delivery status for a specific order
	        String query = "SELECT DeliveryStatus FROM Orders WHERE OrderID = ?";
	        pst = conn.prepareStatement(query);
	        pst.setInt(1, orderID);
	        rs = pst.executeQuery();

	        return rs.next() ? rs.getString("DeliveryStatus") : "N/A";
	    }

	    private static boolean isValidStatus(String status) {
	        return "delivered".equals(status) || "pending".equals(status) || "processing".equals(status);
	    }

//	    private static void closeResources() {
//	        try {
//	            if (rs != null) {
//	                rs.close();
//	            }
//	            if (pst != null) {
//	                pst.close();
//	            }
//	            if (conn != null) {
//	                conn.close();
//	            }
//	        } catch (SQLException e) {
//	            e.printStackTrace();
//	        }
//	    }
//	        
	        public static void viewDeliveryStatus(int orderID) throws SQLException {
	            conn = DataBaseConnection.getConnection();

	            // SQL query to retrieve the delivery status for the specified order
	            String query = "SELECT DeliveryStatus FROM Orders WHERE OrderID = ?";
	            pst = conn.prepareStatement(query);
	            pst.setInt(1, orderID);
	            rs = pst.executeQuery();

	            if (rs.next()) {
	                String deliveryStatus = rs.getString("DeliveryStatus");
	                System.out.println("Delivery Status for Order ID " + orderID + ": " + deliveryStatus);
	            } else {
	                System.out.println("No delivery status found for Order ID " + orderID);
	            }
	        }
	        
	        public static void viewOrderID(int userID) throws SQLException {
	        	 conn = DataBaseConnection.getConnection();
	        	 // Query to retrieve order ID for a specific user
	             String query = "SELECT orderID FROM orders WHERE userID = ?";
	             pst = conn.prepareStatement(query);
		         pst.setInt(1, userID);
		         rs = pst.executeQuery();
		         if (rs.next()) {
                     int orderID = rs.getInt("orderID");
                     System.out.println("Your order ID is: " + orderID);
                     viewDeliveryStatus(orderID); // Call the method to view delivery status
                 } else {
                     System.out.println("No order found for the given user ID.");
                 }
	        	
	        }
	}
	  




